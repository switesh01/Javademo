package com.lt.constant;
/**
 * 
 * @author JEDI-03
 *
 */
public enum NotificationType {
	REGISTRATION,REGISTRATION_APPROVAL,PAYMENT;
}
