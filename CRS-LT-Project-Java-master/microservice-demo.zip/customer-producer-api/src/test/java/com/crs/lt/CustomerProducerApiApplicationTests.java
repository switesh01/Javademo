package com.crs.lt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerProducerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
